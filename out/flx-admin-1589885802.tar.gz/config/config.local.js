'use strict';

module.exports = {
  react: {},
};
