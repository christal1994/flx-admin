'use strict';

exports.validate = {
  enable: true,
  package: 'egg-validate',
};

exports.security = {
  enable: false,
};

exports.userrole = {
  package: 'egg-userrole',
};
