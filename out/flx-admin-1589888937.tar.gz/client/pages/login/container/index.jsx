import React from 'react';
import { connect } from 'react-redux';
import { Button, Row, Form, Input } from 'antd';
import classNames from 'classnames/bind';
import actions from '../actions';
import style from './index.module.less';
import logo from '../../../assets/logo.png';

const cx = classNames.bind(style);
const FormItem = Form.Item;

const Login = ({
  dispatch,
  form: { getFieldDecorator, validateFieldsAndScroll },
  message: { error, text },
  loading,
  logined,
}) => {
  function handleOk() {
    validateFieldsAndScroll((errors, values) => {
      if (errors) {
        return;
      }
      dispatch(actions.login(values));
    });
  }

  return (
    <div className={cx('form')}>
      <div className={cx('logo')}>
        <img alt={'logo'} src={logo} />
        <span>Admin Login</span>
      </div>
      <form>
        <FormItem hasFeedback>
          {getFieldDecorator('username', {
            rules: [
              {
                required: true,
              },
            ],
          })(
            <Input
              size="large"
              onPressEnter={handleOk}
              placeholder="用户名"
            />
          )}
        </FormItem>
        <FormItem hasFeedback>
          {getFieldDecorator('password', {
            rules: [
              {
                required: true,
              },
            ],
          })(
            <Input
              size="large"
              type="password"
              onPressEnter={handleOk}
              placeholder="密码"
            />
          )}
        </FormItem>
        <Row>
          <Button
            type="primary"
            size="large"
            loading={loading}
            onClick={handleOk}
            disabled={logined}
          >
            {logined ? '登录成功' : '登录'}
          </Button>
          <p className={cx({ error })}>{text}</p>
        </Row>
      </form>
    </div>
  );
};

export default connect(state => state)(
  Form.create({
    onFieldsChange(props, changedFields) {
      props.dispatch(actions.fieldChange(changedFields));
    },
    mapPropsToFields(props) {
      return {
        username: Form.createFormField({
          ...props.username,
          value: props.username.value,
        }),
        password: Form.createFormField({
          ...props.password,
          value: props.password.value,
        }),
      };
    },
  })(Login)
);
